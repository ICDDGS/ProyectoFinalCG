Sonic ripped for The Models Resource by josh98

Thanks to ItsEasyActually and Random Talking Bush for the script!